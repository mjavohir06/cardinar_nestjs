import { Module } from '@nestjs/common';
import { StaticModule } from './features/static/Static.module';
import { APP_GUARD } from '@nestjs/core';
import { AuthenticationGuard } from './core/guards/authentication.guard';
import { RolesGuard } from './core/guards/roles.guard';
import { JwtModule } from '@nestjs/jwt';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigModule } from '@nestjs/config';
import { configModuleOptions } from './configs/env.config';
import { typeOrmConfig } from './configs/type-orm.config';
import { jwtModuleConfig } from './configs/jwt-module.config';


@Module({
  providers: [
    { provide: APP_GUARD, useClass: AuthenticationGuard },
    { provide: APP_GUARD, useClass: RolesGuard },
  ],
  imports: [
    JwtModule.register(jwtModuleConfig),
    TypeOrmModule.forRoot(typeOrmConfig),
    ConfigModule.forRoot(configModuleOptions),
    StaticModule
  ],
})
export class AppModule {}
