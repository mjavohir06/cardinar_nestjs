import { Injectable, NotFoundException } from "@nestjs/common";
import { BannerCreateDto } from "../../dtos/admin/banner/banner.create.dto";
import { BannerRepository } from "../../repositories/banner.repository";
import { BannerEntity } from "../../entities/banner.entity";
import { BannerUpdateDto } from "../../dtos/admin/banner/banner.update.dto";
import { SearchFilters } from "@/core/filters/search.filters";


@Injectable()
export class BannerAdminService {

    constructor(private readonly repo:BannerRepository){

    }

    async create(payload:BannerCreateDto, image: Express.Multer.File){
        return await this.repo.save({...payload,image:image.path} as BannerEntity)
    }

    async getAll(filters:SearchFilters){

        return await this.repo.getAll(filters)
    }

    async update(id:number,payload:BannerUpdateDto, image?: Express.Multer.File){
        const banner=await this.repo.findOneBy({id})
        if(!banner) throw new NotFoundException("Bunday idli banner topilmadi!")
        if(image) banner.image=image.path
        
        Object.assign(
            banner,
            Object.fromEntries(Object.entries(payload).filter(([key,value])=>value!==null))
        )

        return await this.repo.save(banner)
    }

    async delete(id:number){
        const banner=await this.repo.findOneBy({id})
        if(!banner) throw new NotFoundException("Bunday idli banner topilmadi!")
        return await this.repo.remove(banner)
    }
}