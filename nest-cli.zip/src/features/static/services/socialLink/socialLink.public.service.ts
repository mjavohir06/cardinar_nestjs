import { Injectable } from "@nestjs/common";
import { SearchFilters } from "@/core/filters/search.filters";
import { SocialLinkRepository } from "../../repositories/socialLink.repository";
import { plainToInstance } from "class-transformer";
import { SocialLinkPublicListDto } from "../../dtos/public/socialLink/socialLink.list.dto";


@Injectable()
export class SocialLinkPublicService {

    constructor(private readonly repo:SocialLinkRepository){

    }


    async getAll(filters:SearchFilters){

        const result=await this.repo.getAll(filters)
        result.data=plainToInstance(SocialLinkPublicListDto,result.data,{excludeExtraneousValues:true}) as []
        return result
    }

}