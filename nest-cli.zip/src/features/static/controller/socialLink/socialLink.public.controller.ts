
import { Controller, Get,  Query, Req,  } from "@nestjs/common";
import {  ApiOkResponse, ApiTags } from "@nestjs/swagger";
import { SearchFilters } from "@/core/filters/search.filters";
import { PaginatedResultDto } from "@/core/paginated-result.dto";
import getFullPath from "@/core/utils/get-full-path";
import type{ Request } from "express";
import { BannerPublicService } from "../../services/banner/Banner.public.service";
import { BannerPublicListDto } from "../../dtos/public/banner/banner.list.dto";
import { SocialLinkPublicListDto } from "../../dtos/public/socialLink/socialLink.list.dto";
import { SocialLinkPublicService } from "../../services/socialLink/socialLink.public.service";



@ApiTags('SocialLink - Public')
@Controller('public/socialLink')
export class SocialLinkPublicController {
  constructor(private readonly service:SocialLinkPublicService ) { }

  @Get()
  @ApiOkResponse({type:PaginatedResultDto(SocialLinkPublicListDto)})
  async getAll(@Query() filters: SearchFilters,@Req() req:Request) {
    const result=await this.service.getAll(filters)
    result.data.forEach((item) => (item.icon = getFullPath(req, item.icon)))
    return result
  }
}
